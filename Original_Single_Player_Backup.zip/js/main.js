/* RAVENWOOD: THE LAST MISSION | main.js  Startup. */
(function(){
'use strict';
var Z=window.Z,$=Z.$;
function start(){
  Z.UI.init();Z.Game.init();Z.TTS.init();
  var resumed=Z.Save.load();
  Z.Engine.init($('#game'));
  Z.Game.restart(resumed);
  if(resumed&&Z.state.introDone)Z.notice('Welcome back. Your saved progress was restored.');
  window.addEventListener('beforeunload',function(){Z.Save.saveNow(true);});
  document.addEventListener('visibilitychange',function(){if(document.hidden)Z.Save.saveNow(true);});
  Z.ready=true;
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
