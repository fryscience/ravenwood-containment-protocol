/* RAVENWOOD: THE LAST MISSION | preview.js
   Teacher preview mode. Only active when the page address ends with ?preview.
   Lets a teacher jump to any zone without completing the earlier ones.
   Uses its own save slot, so it never touches a normal save. Students never see it. */
(function(){
'use strict';
var Z=window.Z,$=Z.$,esc=Z.esc;
var on=window.RW_PREVIEW===true||/(^|[?&])preview(=|&|$)/.test(window.location.search);
Z.preview=on;
if(!on)return;
Z.KEY=Z.KEY+'.preview';

var ZONE_SET={
 1:{flags:['z1_gate1','z1_console'],items:['access_card','power_cell','doc_log'],used:['access_card','power_cell']},
 2:{flags:['z2_power'],items:['fuse'],used:['fuse'],done:['doc_metab']},
 3:{flags:['z3_gate','z3_chip'],items:['valve','chip'],used:['valve','chip']},
 4:{flags:['z4_a','z4_b'],items:['rec1','rec2','rec3'],used:['rec1','rec2'],done:['doc_neuro']},
 5:{flags:['z5_gate1','z5_gate2','z5_term'],items:['keycard5','rec_nut','rec_o2','rec_pump','rec_cam'],used:['keycard5'],lore:['z5_panel'],done:['doc_memo']},
 6:{flags:['z6_door','z6_board'],items:[],used:[]}
};

function finish(s,n){
  if(n===1){Z.T1.forEach(function(e){s.p1.ok[e.id]=true;});}
  if(n===2){s.p2.goalA=true;s.p2.goalB=true;s.p2.qok=true;}
  if(n===3){s.p3.tested={adequate:true,reduced:true,severe:true};s.p3.selOk=true;s.p3.whyOk=true;}
  if(n===4){s.p4.ok1=true;s.p4.ok2=true;s.p4.goalOk=true;s.p4.stmtOk=true;}
  if(n===5){s.p5.views={cam:true,pump:true,o2:true,nut:true};s.p5.matchOk=true;s.p5.claimsOk=true;}
  if(n===6){
    s.p6.choice='B';
    s.p6.sel={e_bursts:true,e_regen:true,e_glyc:true,e_reflex:true,e_pump:true};
    s.p6.cer={
     claim:'I claim that the movement is best explained by living tissue kept working by outside support, not by a loss of biological limits.',
     evidence:'Evidence from Zone 5 shows that every large burst happened while the pump delivered oxygen and nutrients, and Zone 2 shows that ATP must be regenerated between bursts.',
     reasoning:'Together, these results show that the tissue still needs oxygen and ATP regeneration, which means an outside supply best explains the sustained movement.'};
    s.p6.submitted=true;
  }
}
function addSet(s,n,withDocs){
  var d=ZONE_SET[n];
  d.flags.forEach(function(k){s.flags[k]=true;});
  d.items.forEach(function(k){s.items[k]=true;});
  d.used.forEach(function(k){s.used[k]=true;});
  (d.lore||[]).forEach(function(k){s.lore[k]=true;});
  if(withDocs)(d.done||[]).forEach(function(k){s.items[k]=true;});
}
function build(zone,openThis,everything){
  var s=Z.defState(),i;
  s.introDone=true;s.zone=zone;
  for(i=1;i<=zone;i++)s.visited[i]=true;
  for(i=1;i<zone;i++){addSet(s,i,true);finish(s,i);}
  if(everything){addSet(s,zone,true);finish(s,zone);}
  else if(openThis){addSet(s,zone,false);}
  return s;
}
function jump(zone,openThis,everything){
  Z.state=build(zone,openThis,everything);
  Z.Save.saveNow(true);
  Z.Game.restart(false);
}
function resetPreview(){
  try{window.localStorage.removeItem(Z.KEY);}catch(e){}
  Z.state=Z.defState();Z.state.introDone=true;Z.Game.restart(false);
}
function open(){
  var r=Z.UI.modal({title:'Teacher preview'});
  var h='<div class="card"><p><b>Preview mode.</b> Jump to any zone without finishing the ones before it. Earlier zones are filled in for you, so their doors, evidence and findings are in place. This uses a separate save in this browser. It does not change a normal save, and students never see this button unless they add <code>?preview</code> to the link.</p>';
  h+='<p><label><input type="checkbox" id="pv-open" checked> Open this zone\'s doors and give me its items, so I can walk through it and see every room. Its puzzle is still left for me to try.</label></p></div>';
  h+='<div style="display:grid;gap:.5rem;max-width:520px;margin:.6rem 0">';
  for(var i=1;i<=6;i++){var z=Z.ZONES[i];h+='<button type="button" class="btn" data-pz="'+i+'">Go to Zone '+i+': '+esc(z.name)+'</button>';}
  h+='<button type="button" class="btn gold" id="pv-all">Everything finished: Zone 6 with the certificate unlocked</button>';
  h+='<button type="button" class="btn" id="pv-reset">Clear the preview save and start over</button></div>';
  r.body.innerHTML=h;
  r.body.addEventListener('click',function(e){
    var b=e.target.closest('button');if(!b)return;
    var ov=r.body.querySelector('#pv-open').checked;
    if(b.dataset.pz){r.close();jump(parseInt(b.dataset.pz,10),ov,false);}
    else if(b.id==='pv-all'){r.close();jump(6,true,true);}
    else if(b.id==='pv-reset'){r.close();resetPreview();}
  });
  setTimeout(function(){r.focusFirst();},0);
}
function init(){
  var nav=$('.bar-main');if(!nav)return;
  var b=document.createElement('button');b.type='button';b.className='btn gold';b.id='b-preview';b.textContent='Teacher preview';
  b.addEventListener('click',open);nav.insertBefore(b,nav.firstChild);
}
Z.Preview={open:open,jump:jump,build:build};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
